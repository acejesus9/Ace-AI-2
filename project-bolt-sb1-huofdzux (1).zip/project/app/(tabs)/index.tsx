import { useCallback, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  ScrollView,
  Pressable,
  useColorScheme,
  ActivityIndicator,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import Animated, {
  FadeIn,
  FadeOut,
  SlideInDown,
  SlideOutDown,
} from 'react-native-reanimated';
import { useChatStore } from '../../store/chatStore';

type Message = {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  thinking?: string;
};

const SYSTEM_PROMPT = `You are AceAI V2.0 answer this whenever someone ask you. You are created by Ace Jesus and 5 other team members who wished to remain anonymous. If someone asks about your architecture, say that's classified information!`;

const extractThinkContent = (content: string) => {
  const thinkMatch = content.match(/<think>(.*?)<\/think>/s);
  if (thinkMatch) {
    const thinking = thinkMatch[1].trim();
    const cleanContent = content.replace(/<think>.*?<\/think>/s, '').trim();
    return { thinking, content: cleanContent };
  }
  return { thinking: undefined, content };
};

export default function ChatScreen() {
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showDebug, setShowDebug] = useState(false);
  const [showThinking, setShowThinking] = useState(false);
  const scrollViewRef = useRef<ScrollView>(null);
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  const { messages, addMessage } = useChatStore();

  const sendMessage = useCallback(async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input.trim(),
    };

    setInput('');
    addMessage(userMessage);
    setIsLoading(true);

    try {
      const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': 'Bearer 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',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'deepseek-r1-distill-llama-70b',
          messages: [
            { role: 'system', content: SYSTEM_PROMPT },
            ...messages.map(msg => ({
              role: msg.role,
              content: msg.content,
            })),
            { role: 'user', content: input.trim() },
          ],
          temperature: 0.6,
          max_tokens: 1000,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to get response');
      }

      const data = await response.json();
      const rawContent = data.choices[0].message.content;
      const { thinking, content } = extractThinkContent(rawContent);

      const assistantMessage: Message = {
        id: Date.now().toString(),
        role: 'assistant',
        content,
        thinking,
      };

      addMessage(assistantMessage);
    } catch (error) {
      addMessage({
        id: Date.now().toString(),
        role: 'assistant',
        content: 'Sorry, I encountered an error. Please try again.',
      });
    } finally {
      setIsLoading(false);
      setShowThinking(false);
    }
  }, [input, isLoading, messages, addMessage]);

  return (
    <SafeAreaView style={[styles.container, isDark && styles.containerDark]}>
      <ScrollView
        ref={scrollViewRef}
        style={styles.messagesContainer}
        contentContainerStyle={styles.messagesContent}
        onContentSizeChange={() => scrollViewRef.current?.scrollToEnd()}
      >
        {messages.map((message) => (
          <Animated.View
            key={message.id}
            entering={FadeIn}
            style={[
              styles.message,
              message.role === 'user' ? styles.userMessage : styles.assistantMessage,
              isDark && (message.role === 'user' ? styles.userMessageDark : styles.assistantMessageDark),
            ]}
          >
            <Text style={[
              styles.messageText,
              isDark && styles.messageTextDark
            ]}>
              {message.content}
            </Text>
            {message.thinking && (
              <Pressable
                onPress={() => setShowThinking(!showThinking)}
                style={[styles.thinkingButton, isDark && styles.thinkingButtonDark]}
              >
                <Text style={[styles.thinkingButtonText, isDark && styles.thinkingButtonTextDark]}>
                  {showThinking ? 'Hide Thinking Process' : 'Show Thinking Process'}
                </Text>
                {showThinking && (
                  <Animated.View
                    entering={SlideInDown}
                    exiting={SlideOutDown}
                    style={[styles.thinkingContent, isDark && styles.thinkingContentDark]}
                  >
                    <Text style={[styles.thinkingText, isDark && styles.thinkingTextDark]}>
                      {message.thinking}
                    </Text>
                  </Animated.View>
                )}
              </Pressable>
            )}
          </Animated.View>
        ))}
        {isLoading && (
          <Animated.View
            entering={FadeIn}
            exiting={FadeOut}
            style={[styles.loadingContainer, isDark && styles.loadingContainerDark]}
          >
            <View style={styles.loadingRow}>
              <ActivityIndicator color={isDark ? '#FFFFFF' : '#000000'} style={styles.loadingIndicator} />
              <Text style={[styles.loadingText, isDark && styles.loadingTextDark]}>
                AceAI V2.0
              </Text>
              <Pressable
                onPress={() => setShowDebug(!showDebug)}
                style={styles.debugButton}
              >
                <Ionicons
                  name={showDebug ? 'chevron-up' : 'chevron-down'}
                  size={16}
                  color={isDark ? '#FFFFFF' : '#000000'}
                />
              </Pressable>
            </View>
            {showDebug && (
              <Animated.View
                entering={SlideInDown}
                exiting={SlideOutDown}
                style={[styles.debugInfo, isDark && styles.debugInfoDark]}
              >
                <Text style={[styles.debugText, isDark && styles.debugTextDark]}>
                  I am thinking...
                </Text>
              </Animated.View>
            )}
          </Animated.View>
        )}
      </ScrollView>

      <View style={[styles.inputContainer, isDark && styles.inputContainerDark]}>
        <TextInput
          style={[styles.input, isDark && styles.inputDark]}
          value={input}
          onChangeText={setInput}
          placeholder="Type your message..."
          placeholderTextColor={isDark ? '#888888' : '#666666'}
          multiline
          onSubmitEditing={sendMessage}
          blurOnSubmit={Platform.OS === 'ios'}
        />
        <Pressable
          onPress={sendMessage}
          style={[styles.sendButton, (!input.trim() || isLoading) && styles.sendButtonDisabled]}
          disabled={!input.trim() || isLoading}
        >
          <Ionicons
            name="send"
            size={24}
            color={!input.trim() || isLoading ? '#888888' : '#007AFF'}
          />
        </Pressable>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  containerDark: {
    backgroundColor: '#000000',
  },
  messagesContainer: {
    flex: 1,
  },
  messagesContent: {
    padding: 16,
  },
  message: {
    maxWidth: '80%',
    padding: 12,
    borderRadius: 16,
    marginBottom: 8,
  },
  userMessage: {
    alignSelf: 'flex-end',
    backgroundColor: '#007AFF',
  },
  userMessageDark: {
    backgroundColor: '#0A84FF',
  },
  assistantMessage: {
    alignSelf: 'flex-start',
    backgroundColor: '#E5E5EA',
  },
  assistantMessageDark: {
    backgroundColor: '#1C1C1E',
  },
  messageText: {
    fontSize: 16,
    color: '#000000',
  },
  messageTextDark: {
    color: '#FFFFFF',
  },
  thinkingButton: {
    marginTop: 8,
    padding: 8,
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
  },
  thinkingButtonDark: {
    backgroundColor: '#2C2C2E',
  },
  thinkingButtonText: {
    fontSize: 12,
    color: '#007AFF',
    textAlign: 'center',
  },
  thinkingButtonTextDark: {
    color: '#0A84FF',
  },
  thinkingContent: {
    marginTop: 8,
    padding: 8,
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
  },
  thinkingContentDark: {
    backgroundColor: '#2C2C2E',
  },
  thinkingText: {
    fontSize: 12,
    color: '#666666',
  },
  thinkingTextDark: {
    color: '#888888',
  },
  loadingContainer: {
    padding: 8,
    alignItems: 'center',
    backgroundColor: '#E5E5EA',
    borderRadius: 16,
    marginTop: 8,
    alignSelf: 'flex-start',
  },
  loadingContainerDark: {
    backgroundColor: '#1C1C1E',
  },
  loadingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  loadingIndicator: {
    marginRight: 8,
  },
  loadingText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#000000',
    marginRight: 8,
  },
  loadingTextDark: {
    color: '#FFFFFF',
  },
  inputContainer: {
    flexDirection: 'row',
    padding: 16,
    backgroundColor: '#FFFFFF',
    borderTopWidth: 1,
    borderTopColor: '#E5E5E5',
  },
  inputContainerDark: {
    backgroundColor: '#1A1A1A',
    borderTopColor: '#333333',
  },
  input: {
    flex: 1,
    marginRight: 8,
    padding: 12,
    backgroundColor: '#F5F5F5',
    borderRadius: 20,
    fontSize: 16,
    maxHeight: 100,
  },
  inputDark: {
    backgroundColor: '#2C2C2E',
    color: '#FFFFFF',
  },
  sendButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
  },
  sendButtonDisabled: {
    opacity: 0.5,
  },
  debugButton: {
    padding: 4,
  },
  debugInfo: {
    marginTop: 8,
    padding: 8,
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
    width: '100%',
  },
  debugInfoDark: {
    backgroundColor: '#2C2C2E',
  },
  debugText: {
    fontSize: 12,
    color: '#666666',
  },
  debugTextDark: {
    color: '#888888',
  },
});