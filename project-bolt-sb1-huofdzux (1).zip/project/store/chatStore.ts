import { create } from 'zustand';

type Message = {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  thinking?: string;
};

type ChatStore = {
  messages: Message[];
  addMessage: (message: Message) => void;
  clearMessages: () => void;
};

export const useChatStore = create<ChatStore>((set) => ({
  messages: [],
  addMessage: (message) =>
    set((state) => ({
      messages: [...state.messages, message],
    })),
  clearMessages: () => set({ messages: [] }),
}));